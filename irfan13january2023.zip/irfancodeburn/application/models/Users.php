<?php

class Users extends CI_Model{

    public function get_where($username, $password)
    {
        return $this->db->get_where("users", array('username' => $username, 'password' => $password));
    }

    public function insert($username, $password)
    {
        return $this->db->insert('users', array('username' => $username, 'password' => $password));
    }

}

?>