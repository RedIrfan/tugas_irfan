<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		$data["title"] = "Home";
		$data["username"] = "";
		if (isset($_SESSION["username"])){
			$data["username"] = $_SESSION["username"];
		}

		$this->load->view("header", $data);
		$this->load->view("home");
	}

	public function about()
	{
		$data["title"] = "About";
		$data["username"] = "";
		if (isset($_SESSION["username"])){
			$data["username"] = $_SESSION["username"];
		}
		
		$this->load->view("header", $data);
		$this->load->view("about");
	}
}
