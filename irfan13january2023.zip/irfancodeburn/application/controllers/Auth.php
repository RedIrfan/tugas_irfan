<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    function __construct(){
        parent::__construct();
        $this->load->model('users');
    }

    public function login()
    {
        $this->load->view("auth/login");
    }

    public function register()
    {
        $this->load->view("auth/register");
    }

    public function login_auth()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        $user = $this->users->get_where($username, $password)->result();
        
        if (count($user) > 0){
            $_SESSION["username"] = $username;
            redirect('home');
        }
        else{
            redirect("login");
        }
        
    }

    public function register_auth()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        $user = $this->users->insert($username, $password);

        if ($user){
            redirect("login");
        }
        else{
            redirect('register');
        }
    }

    public function logout()
    {
        unset($_SESSION["username"]);

        redirect('home');
    }
}
