<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <title>Irfan School - <?= $title ?></title>
</head>
<style>
    a{
        text-decoration: none;
    }
</style>
<body>
    <div class="bg-primary text-white mb-2">
        <div class="justify-content-between d-flex container">
            <a class="h2" href="home">Irfan School</a>
            <div class="align-items-center d-flex">
                <a href="about" class="btn btn-primary me-1">About</a>
                <?php if ($username == "") : ?>
                    <a href="login" class="btn btn-primary me-1">Login</a>
                    <a href="register" class="btn btn-primary">Register</a>
                <?php else :?>
                    <a href="logout" class="btn btn-primary">Logout</a>
                <?php endif ?>
            </div>
        </div>
    </div>