<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <title>Irfan School - Register</title>
</head>
<body>
    <div class="container">
        <div class="card w-50 mx-auto mt-5">
            <div class="card-header bg-primary text-center text-white">
                <h1>Register</h1>
            </div>
            <div class="card-body">
                <div class="container">
                    <form action="register/auth" method="post">
                        <div class="row row-cols-2">
                                <label for="username">Username</label>
                            <div>
                                <input type="text" class="form-control" id="username" name="username" required>
                            </div>
                            
                            <label for="password">Password</label>
                            <div>
                                <input type="password" class="form-control" id="password" name="password"required>
                            </div>
                            
                            <div></div>
                        </div>
                        <div class="pt-3 text-center">
                            <button class="btn btn-primary w-100">Register</button>
                            <a href="login">Login</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>