    <div class="container">
        <img src="https://thumbs.dreamstime.com/b/generic-high-school-building-streetview-facade-made-red-brick-stone-green-lawn-bushes-front-clear-33564186.jpg" alt="" class="w-50 mx-auto d-block">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum quis iure, sunt tempora enim dolor voluptate ullam exercitationem, corrupti consequuntur quos quaerat nesciunt alias voluptas dignissimos laudantium impedit ipsum quidem?</p>
    </div>
</body>
</html>