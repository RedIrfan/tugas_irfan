    <div class="container">
        <img src="https://thumbs.dreamstime.com/b/generic-high-school-building-streetview-facade-made-red-brick-stone-green-lawn-bushes-front-clear-33564186.jpg" alt="" class="w-50 float-start">
        <p>Irfan School is a school made by a student. it was created in the 13th of january 2023.</p>
    </div>
</body>
</html>